const toggle=document.getElementById("menuToggle");
const menu=document.getElementById("mobileMenu");
const close=document.getElementById("menuClose");
const backdrop=document.getElementById("menuBackdrop");
function setMenu(open){
  menu.classList.toggle("open",open);
  backdrop.classList.toggle("open",open);
  menu.setAttribute("aria-hidden",String(!open));
  toggle.setAttribute("aria-expanded",String(open));
  document.body.style.overflow=open?"hidden":"";
}
toggle.addEventListener("click",()=>setMenu(true));
close.addEventListener("click",()=>setMenu(false));
backdrop.addEventListener("click",()=>setMenu(false));
document.querySelectorAll(".mobile-menu a").forEach(a=>a.addEventListener("click",()=>setMenu(false)));
