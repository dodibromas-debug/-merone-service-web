# MERONE SERVICE SRL — WEB FINAL

Sitio estático listo para Cloudflare. No necesita Node, React ni una carpeta `dist`.

## Estructura
- `index.html` — página completa
- `styles.css` — diseño responsive
- `script.js` — menú móvil
- `assets/` — logo + fotografías locales
- `_headers` — headers básicos
- `README.md` — instrucciones

## IMPORTANTE PARA CLOUDFLARE
Este proyecto es una web estática. Si estás usando **Cloudflare Pages por GitHub**, el repositorio debe contener `index.html` en la raíz.

Para Pages con un comando de despliegue, usa:
`npx wrangler pages deploy . --project-name=merone-service-web`

No uses `npx wrangler deploy` para este proyecto de Pages estático; ese comando es para un Worker configurado.

Si usas **Cloudflare Pages > Direct Upload**, Cloudflare permite arrastrar un ZIP o una carpeta de assets. El ZIP de este paquete está preparado para ese método.

## WhatsApp
Todos los botones de cotización abren WhatsApp al +1 (829) 755-9560 con un mensaje específico por servicio.

## Redes
Instagram, Facebook y TikTok están conectados a los perfiles suministrados para Merone Service SRL.

## Nota
No se inventó correo electrónico. Si luego quieres agregar email, horario, mapa o testimonios reales, se pueden añadir sin cambiar la estructura.
