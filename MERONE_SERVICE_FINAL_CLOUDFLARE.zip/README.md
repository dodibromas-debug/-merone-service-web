# MERONE SERVICE SRL

Proyecto final estático preparado para Cloudflare Workers Static Assets.

## Cloudflare
Build command: dejar vacío
Deploy command: `npx wrangler deploy`
Preview command: `npx wrangler dev`

No requiere framework ni build. El archivo `wrangler.toml` ya está incluido.

## Estructura
- `public/index.html`
- `public/styles.css`
- `public/script.js`
- `public/assets/logo.png`
- `public/assets/hero-comejen.png`
- `wrangler.toml`
