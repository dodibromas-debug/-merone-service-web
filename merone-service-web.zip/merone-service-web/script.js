const menu=document.getElementById('mobileMenu');
const toggle=document.querySelector('.menu-toggle');
const close=document.querySelector('.menu-close');
const closeMenu=()=>{menu.classList.remove('open');menu.setAttribute('aria-hidden','true');toggle?.setAttribute('aria-expanded','false');document.body.style.overflow=''};
toggle?.addEventListener('click',()=>{menu.classList.add('open');menu.setAttribute('aria-hidden','false');toggle.setAttribute('aria-expanded','true');document.body.style.overflow='hidden'});
close?.addEventListener('click',closeMenu);
menu?.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{if(a.getAttribute('href')?.startsWith('#'))closeMenu()}));
document.getElementById('year').textContent=new Date().getFullYear();
