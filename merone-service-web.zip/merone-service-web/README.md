# Merone Service SRL — Web

Sitio estático, responsive y listo para publicar en Cloudflare Pages.

## Publicar con GitHub + Cloudflare Pages

1. Crea un repositorio nuevo en GitHub, por ejemplo `merone-service-web`.
2. Sube **todo el contenido de esta carpeta** al repositorio. `index.html` debe quedar en la raíz.
3. En Cloudflare entra a **Workers & Pages → Create application → Pages → Connect to Git**.
4. Selecciona el repositorio.
5. Framework preset: **None**.
6. Build command: déjalo vacío.
7. Build output directory: `/` o la raíz del proyecto.
8. Guarda y despliega.
9. Cloudflare te dará una dirección `*.pages.dev`.
10. Cuando compres/conectes el dominio de Merone Service, entra en **Custom domains** y agrégalo.

## WhatsApp

Todos los botones principales y cada servicio apuntan al WhatsApp +1 (829) 755-9560 con un mensaje prellenado.

## Antes de lanzar

- Sustituir `assets/logo-mark.svg` por el logo oficial de alta resolución si se dispone del archivo original.
- Confirmar con Merone Service que está autorizado el uso del nombre/logo de Noval en la sección de experiencia.
- Añadir email y horarios cuando el cliente los confirme.
- Reemplazar las imágenes de fondo externas por fotografías propias cuando estén disponibles para un resultado 100% de marca.
