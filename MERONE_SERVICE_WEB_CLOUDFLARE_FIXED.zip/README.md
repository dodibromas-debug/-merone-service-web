# MERONE SERVICE SRL — Cloudflare Workers Static Assets

Sitio web estático listo para el flujo **Workers Builds + Wrangler Static Assets** de Cloudflare.

## Estructura
- `public/index.html` — página principal
- `public/styles.css` — estilos responsive
- `public/script.js` — menú móvil
- `public/assets/` — logo y fotografías
- `wrangler.jsonc` — configuración de Cloudflare Workers Static Assets

## Configuración de Cloudflare
Usa estos valores en **Workers & Pages → Settings → Builds**:

- Root directory: `/`
- Build command: `exit 0`
- Deploy command: `npx wrangler deploy`
- Production branch: `main`

No cambies el Deploy command a `wrangler pages deploy` en este proyecto. Este paquete está configurado específicamente para Workers Static Assets.

## GitHub
El contenido de este paquete debe quedar en el repositorio con esta estructura:

```text
wrangler.jsonc
public/
  index.html
  styles.css
  script.js
  assets/
```

## WhatsApp
Los botones de cotización abren WhatsApp al +1 (829) 755-9560 con mensajes específicos por servicio.

## Redes
Instagram, Facebook y TikTok están conectados a los perfiles suministrados para Merone Service SRL.
